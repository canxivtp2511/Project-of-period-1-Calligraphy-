eProject T1.2011.M0-eProject-Group_2 Batch no.: T1.2011.M0

CENTER NAME: ACE-HCMC-2-FPT

Project title: Calligraphy

========> Group 2 <=========

4 collaborators:

 Group members	            Name	                    Student ID

                            Vũ Trọng Phong            Studenn1285594
                            Đỗ Trần Long              Student1287966
                            Bùi Đại Long              Student1281546
                            Lê Thành Ngọc Bích        Student1268354  
============================

eProject documentation at https://github.com/canxivtp2511/eProject1/tree/main/Review

============================

eProject published at https://canxivtp2511.github.io/eProject1/

============================

eProject video published at https://www.youtube.com/watch?v=VEi5quwM6jw

============================

Thank you for spending your time to look at our work.
